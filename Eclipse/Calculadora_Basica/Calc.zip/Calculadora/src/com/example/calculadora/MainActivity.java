
package com.example.calculadora;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ADI��O
        Button mais = (Button) findViewById(R.id.button1);

        mais.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                EditText val1 = (EditText) findViewById(R.id.editText1);
                EditText val2 = (EditText) findViewById(R.id.EditText01);

                double v1 = Double.parseDouble(val1.getText().toString());
                double v2 = Double.parseDouble(val2.getText().toString());

                double resultado = v1 + v2;
                String res = "O resultado �: " + resultado;

                Toast.makeText(MainActivity.this, res, Toast.LENGTH_LONG).show();
            }
        });

        // SUBTRA��O
        Button menos = (Button) findViewById(R.id.Button01);

        menos.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                EditText val1 = (EditText) findViewById(R.id.editText1);
                EditText val2 = (EditText) findViewById(R.id.EditText01);

                double v1 = Double.parseDouble(val1.getText().toString());
                double v2 = Double.parseDouble(val2.getText().toString());

                double resultado = v1 - v2;
                String res = "O resultado �: " + resultado;

                Toast.makeText(MainActivity.this, res, Toast.LENGTH_LONG).show();
            }
        });

        // DIVIS�O
        Button dividir = (Button) findViewById(R.id.Button02);

        dividir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                EditText val1 = (EditText) findViewById(R.id.editText1);
                EditText val2 = (EditText) findViewById(R.id.EditText01);

                double v1 = Double.parseDouble(val1.getText().toString());
                double v2 = Double.parseDouble(val2.getText().toString());

                if (v2 == 0) {
                    Toast.makeText(MainActivity.this, "N�o � poss�vel dividir por zero", Toast.LENGTH_LONG).show();
                    return;
                }

                double resultado = v1 / v2;
                String res = "O resultado �: " + resultado;

                Toast.makeText(MainActivity.this, res, Toast.LENGTH_LONG).show();
            }
        });

        // MULTIPLICA��O
        Button multiplicar = (Button) findViewById(R.id.Button03);

        multiplicar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                EditText val1 = (EditText) findViewById(R.id.editText1);
                EditText val2 = (EditText) findViewById(R.id.EditText01);

                double v1 = Double.parseDouble(val1.getText().toString());
                double v2 = Double.parseDouble(val2.getText().toString());

                double resultado = v1 * v2;
                String res = "O resultado �: " + resultado;

                Toast.makeText(MainActivity.this, res, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
