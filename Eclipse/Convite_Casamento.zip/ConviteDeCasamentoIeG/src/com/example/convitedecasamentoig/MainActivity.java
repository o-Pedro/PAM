
package com.example.convitedecasamentoig;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;

public class MainActivity extends Activity implements Runnable {

    Handler timer = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer.postDelayed(this, 3000);
    }

    @Override
    public void run() {
        startActivity(new Intent(this, SegundaActivity.class));
        MainActivity.this.finish();
    }
}
